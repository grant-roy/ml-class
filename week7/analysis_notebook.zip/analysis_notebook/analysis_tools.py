from __future__ import division
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import math


def misclassified_count(w, data):
    scalar = pd.Series([1] * (len(data)+1), name='scalar')
    y = data['Classification']
    data['scalar'] = scalar
    x = data.drop(['Classification'], axis=1)

    misclassified = 0
    for index, row in x.iterrows():

        y_hat = np.dot(w, row.T, out=None)

        if np.sign(y[index]) != np.sign(y_hat):
            misclassified += 1
    return {'misclassified':misclassified, 'ratio_misclassified':misclassified/len(data)}


def vc_bound(N=1, tolerance=.14, d_vc=1):
    return math.sqrt( (8/N) * math.log( (4 * math.pow(2 * N, d_vc) + 1) /tolerance ) )


def hoeffding_bound(N=1, M=1, tolerance=.01):
    return math.sqrt( (1 / (2 * N)) * math.log((2 * M) / tolerance) )

def rademacher_bound(N=1, d_vc=1, tolerance=.01):
    return math.sqrt( (2 * math.log(2 * N * math.pow(N,d_vc))) / N  ) + \
           math.sqrt( 2 / N * math.log(1 / tolerance) ) + \
           (1 / N)

def pvd_bound(N=1, d_vc=1, tolerance=.01, epsilon=.01):
    try:
        return math.sqrt( (1 / N) * ( 2 * epsilon + math.log( 4 * math.pow(N**2,d_vc) / tolerance )))
    except OverflowError:
        return float('inf')


def devroye_bound(N=1, d_vc=1, tolerance=.01, epsilon=.01):
    try:
        return math.sqrt( 1 / 2 * N * (4*epsilon + 4*epsilon**2 + math.log((4 * math.pow(N**2,d_vc)) / tolerance ) ))
    except OverflowError:
        return float('inf')

def determine_n(error=.01, tolerance=.01, d_vc=1, N=1):
    return (8 / (error ** 2)) * math.log((4 * math.pow(2 * N, d_vc) + 4) / tolerance)

def load_data(file_name='', y_name=''):
    data = pd.read_csv(file_name, header=0)
    data = data.rename(columns = {y_name:'Classification'})
    del data['date']
    data['Classification'] = data['Classification'].apply(lambda value: value if value==1 else -1)
    return data


def print_results(e_in=None, e_test=None, vc=None, hoeffding=None):
    print "\n"
    if e_in:
        print "E_in number misclassified: " + str(e_in['misclassified']) + ", percentage error: " + str(e_in['ratio_misclassified'])
    if e_test:
        print "E_test number misclassified: " + str(e_test['misclassified']) + ", percentage error: " + str(e_test['ratio_misclassified'])
    if vc:
        print "VC bound: " + str(vc)
    if hoeffding:
        print "Hoeffding bound: " + str(hoeffding)
    print "\n"


def compare_generalization_bounds(range_n=None, d_vc=1, tolerance=.01, epsilon=.01):
    vc=[]
    rb=[]
    pv=[]
    db=[]

    for N in range_n:
        vc.append(vc_bound(N=N, tolerance=.1, d_vc=d_vc))
        rb.append(rademacher_bound(N=N, tolerance=.1, d_vc=d_vc))
        pv.append(pvd_bound(N=N, tolerance=.1, d_vc=d_vc, epsilon=epsilon))
        db.append(devroye_bound(N=N, tolerance=.1, d_vc=d_vc, epsilon=epsilon))


    plt.plot(vc,c='r')
    plt.plot(rb,c='g')
    plt.plot(pv,c='y')
    #plt.plot(db)
    plt.show()
